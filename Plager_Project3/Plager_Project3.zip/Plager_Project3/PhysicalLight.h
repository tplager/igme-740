#pragma once
#include "Mesh.h"

class PhysicalLight
{
private: 
public: 
};

